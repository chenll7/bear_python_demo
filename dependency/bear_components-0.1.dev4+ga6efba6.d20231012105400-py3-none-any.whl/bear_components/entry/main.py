def main():
    print(1234567890)

if __name__ == '__main__':
    main()